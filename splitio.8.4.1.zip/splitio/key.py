"""Compatibility module for key."""

from splitio.client.key import Key
