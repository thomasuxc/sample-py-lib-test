from splitio.client.factory import get_factory
from splitio.client.key import Key
from splitio.version import __version__
